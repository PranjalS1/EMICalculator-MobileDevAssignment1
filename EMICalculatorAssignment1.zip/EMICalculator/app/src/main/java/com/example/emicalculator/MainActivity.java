package com.example.emicalculator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.emicalculator.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    EditText principal, rate, time;
    Button calculate, clear;
    TextView result;

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("EMI Calculator");
        principal=findViewById(R.id.txt_principal);
        rate=findViewById(R.id.txt_rate);
        time=findViewById(R.id.txt_time);
        result=findViewById(R.id.txt_emi);
        calculate=findViewById(R.id.btn_calculate);
        clear=findViewById(R.id.btn_clear);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent intentObj = new Intent(Intent.ACTION_VIEW);
                //intentObj.setData(Uri.parse("https://tools.td.com/mortgage-payment-calculator/"));
                //startActivity(intentObj);

                if(principal.equals("")||rate.equals("")||time.equals(""))
                {
                    Toast.makeText(MainActivity.this,"Enter all details!",Toast.LENGTH_SHORT);
                }
                else
                {
                    //EMI Calculation
                    double principal_amt=Double.parseDouble(principal.getText().toString());
                    double roi=Double.parseDouble(rate.getText().toString());
                    double time_m=Double.parseDouble(time.getText().toString());
                    //Formula to calculate EMI
                    roi=(roi/100)/12;
                    time_m=time_m*12;
                    double emi=(principal_amt*roi)/(1-Math.pow(1+roi,-time_m));
                    result.setText(String.valueOf(emi));
                }

            }
        });

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        //Passing each menu ID as a set of IDs
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
    }

}